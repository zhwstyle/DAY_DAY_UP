#!/bin/bash
sudo mkdir /mnt/tensorflow/
sudo mv Python-3.6.4.tgz /mnt/tensorflow/Python-3.6.4.tgz
sudo mv tf_nightly-1.7.0.dev20180314-cp36-cp36m-manylinux1_x86_64.whl /mnt/tensorflow/tf_nightly-1.7.0.dev20180314-cp36-cp36m-manylinux1_x86_64.whl
sudo mv protobuf-3.5.2-cp36-cp36m-manylinux1_x86_64.whl /mnt/tensorflow/protobuf-3.5.2-cp36-cp36m-manylinux1_x86_64.whl
sudo mv six-1.11.0-py2.py3-none-any.whl /mnt/tensorflow/six-1.11.0-py2.py3-none-any.whl
sudo mv gast-0.2.0.tar.gz /mnt/tensorflow/gast-0.2.0.tar.gz
sudo mv grpcio-1.10.0-cp36-cp36m-manylinux1_x86_64.whl /mnt/tensorflow/grpcio-1.10.0-cp36-cp36m-manylinux1_x86_64.whl
sudo mv absl-py-0.1.11.tar.gz /mnt/tensorflow/absl-py-0.1.11.tar.gz
sudo mv numpy-1.14.2-cp36-cp36m-manylinux1_x86_64.whl /mnt/tensorflow/numpy-1.14.2-cp36-cp36m-manylinux1_x86_64.whl
sudo mv tb_nightly-1.7.0a20180314-py3-none-any.whl /mnt/tensorflow/tb_nightly-1.7.0a20180314-py3-none-any.whl
sudo mv html5lib-0.9999999.tar.gz /mnt/tensorflow/html5lib-0.9999999.tar.gz
sudo mv Werkzeug-0.14.1-py2.py3-none-any.whl /mnt/tensorflow/Werkzeug-0.14.1-py2.py3-none-any.whl
sudo mv Markdown-2.6.11-py2.py3-none-any.whl /mnt/tensorflow/Markdown-2.6.11-py2.py3-none-any.whl
sudo mv bleach-1.5.0-py2.py3-none-any.whl /mnt/tensorflow/bleach-1.5.0-py2.py3-none-any.whl
sudo mv termcolor-1.1.0.tar.gz /mnt/tensorflow/termcolor-1.1.0.tar.gz
sudo mv astor-0.6.2-py2.py3-none-any.whl /mnt/tensorflow/astor-0.6.2-py2.py3-none-any.whl
sudo mv wheel-0.30.0-py2.py3-none-any.whl /mnt/tensorflow/wheel-0.30.0-py2.py3-none-any.whl

cd /mnt/tensorflow/
tar zxvf Python-3.6.4.tgz
cd /mnt/tensorflow/Python-3.6.4
./configure
make
make install
cd /mnt/tensorflow/
pip3 install /mnt/tensorflow/six-1.11.0-py2.py3-none-any.whl
pip3 install /mnt/tensorflow/protobuf-3.5.2-cp36-cp36m-manylinux1_x86_64.whl
tar zxvf gast-0.2.0.tar.gz
cd /mnt/tensorflow/gast-0.2.0
python3.6 setup.py install
cd /mnt/tensorflow/
pip3 install /mnt/tensorflow/grpcio-1.10.0-cp36-cp36m-manylinux1_x86_64.whl
tar zxvf absl-py-0.1.11.tar.gz
cd /mnt/tensorflow/absl-py-0.1.11
python3.6 setup.py install
cd /mnt/tensorflow/
pip3 install numpy-1.14.2-cp36-cp36m-manylinux1_x86_64.whl
tar zxvf html5lib-0.9999999.tar.gz
cd /mnt/tensorflow/html5lib-0.9999999
python3.6 setup.py install
cd /mnt/tensorflow/
pip3 install Werkzeug-0.14.1-py2.py3-none-any.whl
pip3 install Markdown-2.6.11-py2.py3-none-any.whl
pip3 install wheel-0.30.0-py2.py3-none-any.whl
pip3 install /mnt/tensorflow/bleach-1.5.0-py2.py3-none-any.whl
pip3 install tb_nightly-1.7.0a20180314-py3-none-any.whl
tar zxvf termcolor-1.1.0.tar.gz
cd /mnt/tensorflow/termcolor-1.1.0
python3.6 setup.py install
cd /mnt/tensorflow/
pip3 install astor-0.6.2-py2.py3-none-any.whl
pip3 install /mnt/tensorflow/tf_nightly-1.7.0.dev20180314-cp36-cp36m-manylinux1_x86_64.whl